# Command-line driver for ogrdbstats

library(ogrdbstats)

genotype_statistics_cmd()